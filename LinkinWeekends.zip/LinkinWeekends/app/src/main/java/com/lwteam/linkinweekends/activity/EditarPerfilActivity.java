package com.lwteam.linkinweekends.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.lwteam.linkinweekends.R;
import com.lwteam.linkinweekends.helper.ConfiguracaoFirebase;
import com.lwteam.linkinweekends.helper.UsuarioFirebase;
import com.lwteam.linkinweekends.model.Usuario;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

import de.hdodenhof.circleimageview.CircleImageView;

public class EditarPerfilActivity extends AppCompatActivity {

    private CircleImageView imageEditarPerfil;
    private TextView textAlterarFoto,editEmailPerfil;
    private TextInputEditText editNomePerfil;
    private Usuario usuarioLogado;
    private Button btSalvarAlteracoes;
    private static final int SELECAO_GALERIA = 200;
    private StorageReference storageRef;
    private String identificadorUsuario;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editar_perfil);

        //CONFIGURACOES INICIAIS
        usuarioLogado   = UsuarioFirebase.getDadosUsuarioLogado();
        storageRef = ConfiguracaoFirebase.getFirebaseStorage();
        identificadorUsuario = UsuarioFirebase.getIdentificadorUsuario();

        //CONFIGURA TOOLBAR
        Toolbar toolbar = findViewById(R.id.toolbarPrincipal);
        toolbar.setTitle("Editar Perfil");
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_close_actionbar_24dp);

        //INICIALIZAR COMPONENTES
        inicializarComponentes();

        //RECUPERAR DADOS DO USUARIO
        FirebaseUser usuarioPerfil = UsuarioFirebase.getUsuarioAtual();
        editNomePerfil.setText(usuarioPerfil.getDisplayName());
        editEmailPerfil.setText(usuarioPerfil.getEmail());

        Uri url = usuarioPerfil.getPhotoUrl();
        if(url!=null){
            Glide.with(EditarPerfilActivity.this)
                   .load(url)
                   .into(imageEditarPerfil);
        }else {
            imageEditarPerfil.setImageResource(R.drawable.avatarperfil);
        }

        //SALVAR ALTERACOES DO NOME
            btSalvarAlteracoes.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String nomeAtualizado = editNomePerfil.getText().toString();

                    //ATUALIZAR NOME DO PERFIL FIREBASE
                    UsuarioFirebase.atualizarNomeUsuario(nomeAtualizado);

                    //ATUALIZAR NOME NO BANCO DE DADOS
                    usuarioLogado.setNome(nomeAtualizado);
                    usuarioLogado.atualizar();

                    Toast.makeText(EditarPerfilActivity.this,
                            "Dados alterados com sucesso!",
                            Toast.LENGTH_SHORT).show();
                }
            });
            //ALTERAR FOTO DO USUARIO
        textAlterarFoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                if(i.resolveActivity(getPackageManager())!=null){
                    startActivityForResult(i,SELECAO_GALERIA);
                }
            }
        });
    }

    @Override
    protected void onActivityResult( int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode==RESULT_OK) {
            Bitmap imagem = null;

            try {
                //SELECAO APENAS DA GALERIA DE FOTOS
                switch (requestCode) {
                    case SELECAO_GALERIA:
                        Uri localImagemSelecionada = data.getData();
                        imagem = MediaStore.Images.Media.getBitmap(getContentResolver(), localImagemSelecionada);
                        break;
                }
                //CASO TENHA ESCOLHIDO UMA IMAGEM
                if (imagem != null) {
                    //CONFIGURA IMAGEM NA TELA
                    imageEditarPerfil.setImageBitmap(imagem);

                    //RECUPERAR DADOS DA IMAGEMPARA O FIREBASE
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    imagem.compress(Bitmap.CompressFormat.JPEG, 70, baos);
                    byte[] dadosImagem = baos.toByteArray();

                    //SALVAR IMAGEM NO FIREBASE
                    final StorageReference imagemRef = storageRef
                            .child("imagens")
                            .child("perfil")
                            .child(identificadorUsuario + ".jpeg");
                    UploadTask uploadTask = imagemRef.putBytes(dadosImagem);
                    uploadTask.addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(EditarPerfilActivity.this,
                                    "Erro ao fazer upload da imagem",
                                    Toast.LENGTH_SHORT).show();
                        }
                    }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            imagemRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {
                                    final String firebaseUrl =uri.toString();
                                    String urlConvertida = firebaseUrl;

                                    // ATUALIZAR FOTO NO PERFIL
                                    UsuarioFirebase.atualizarFotoUsuario(uri);

                                    // ATUALIZAR FOTO NO FIREBASE
                                    usuarioLogado.setCaminhoFoto(urlConvertida);
                                    usuarioLogado.atualizar();
                                    Toast.makeText(EditarPerfilActivity.this,
                                            "Sua foto foi atualizada!",
                                            Toast.LENGTH_SHORT).show();
                                }

                            });
                        }
                    });
                    Toast.makeText(EditarPerfilActivity.this,
                            "Sucesso ao fazer upload da imagem",
                            Toast.LENGTH_SHORT).show();
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void inicializarComponentes(){

        imageEditarPerfil   = findViewById(R.id.imgEditarPerfil);
        textAlterarFoto     = findViewById(R.id.txtAlterarFotoPerfil);
        editNomePerfil      = findViewById(R.id.txtAlterarNomePerfil);
        editEmailPerfil     = findViewById(R.id.txtAlterarEmailPerfil);
        btSalvarAlteracoes  = findViewById(R.id.btnSalvarPerfil);
        editEmailPerfil.setFocusable(false);
    }

    @Override
    public boolean onSupportNavigateUp() {
        startActivity(new Intent(getApplicationContext(),PerfilActivity.class));
        finish();
        return false;
    }
}
