package com.lwteam.linkinweekends.activity;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;
import com.lwteam.linkinweekends.R;
import com.lwteam.linkinweekends.helper.ConfiguracaoFirebase;
import com.lwteam.linkinweekends.helper.UsuarioFirebase;
import com.lwteam.linkinweekends.model.Usuario;

public class CadEmailActivity extends AppCompatActivity {

    private EditText campoNome, campoEmail, campoSenha;
    private Button btCadastrar;
    private ProgressBar progressBar;

    private Usuario usuario;
    private FirebaseAuth autenticacao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cad_email);
        getSupportActionBar().hide();

        inicializarComponentes();

        //cadastro de usuario
        progressBar.setVisibility(View.GONE);
        btCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String textoNome = campoNome.getText().toString();
                String textoEmail = campoEmail.getText().toString();
                String textoSenha = campoSenha.getText().toString();

                if(!textoNome.isEmpty()){
                    if(!textoEmail.isEmpty()){
                        if(!textoSenha.isEmpty()){

                                usuario = new Usuario();
                                usuario.setNome(textoNome);
                                usuario.setEmail(textoEmail);
                                usuario.setSenha(textoSenha);
                                cadastrarUsuario(usuario);

                        }else{
                            Toast.makeText(CadEmailActivity.this,"Preencha a senha!",Toast.LENGTH_SHORT).show();
                        }
                    }else{
                        Toast.makeText(CadEmailActivity.this,"Preencha o email!",Toast.LENGTH_SHORT).show();
                    }
                }else{
                    Toast.makeText(CadEmailActivity.this,"Preencha o nome!",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    //metodo responsavel por cadastrar o user e senha e fazer as validaçoes
    public void cadastrarUsuario(final Usuario usuario){

        progressBar.setVisibility(View.VISIBLE);
        autenticacao = ConfiguracaoFirebase.getFirebaseAutenticacao();
        autenticacao.createUserWithEmailAndPassword(
                usuario.getEmail(),
                usuario.getSenha()
        ).addOnCompleteListener(
                this,
                new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        if (task.isSuccessful()) {

                            try {
                                progressBar.setVisibility(View.GONE);

                                //SALVAR DADOS DO USUARIO NO FIREBASE
                                String idUsuario = task.getResult().getUser().getUid();
                                usuario.setId(idUsuario);
                                usuario.salvar();

                                //SALVAR DADOS NO PROFILE DO FIREBASE
                                UsuarioFirebase.atualizarNomeUsuario(usuario.getNome());


                                Toast.makeText(CadEmailActivity.this,"Cadastro com sucesso",Toast.LENGTH_SHORT).show();

                                startActivity(new Intent(getApplicationContext(),MenuActivity.class));
                                finish();

                            }catch (Exception e ){
                                e.printStackTrace();
                            }

                        } else {

                            progressBar.setVisibility(View.GONE);

                            String erroExcecao = "";
                            try {
                                throw task.getException();
                            } catch (FirebaseAuthWeakPasswordException e) {
                                erroExcecao = "Digite uma senha mais forte!";
                            } catch (FirebaseAuthInvalidCredentialsException e) {
                                erroExcecao = "Por favor, digite um email válido!";
                            } catch (FirebaseAuthUserCollisionException e) {
                                erroExcecao = "Esta conta já foi cadastrada";
                            } catch (Exception e) {
                                erroExcecao = "ao cadastrar usuário: " + e.getMessage();
                                e.printStackTrace();
                            }
                            Toast.makeText(CadEmailActivity.this, "Erro: "+erroExcecao, Toast.LENGTH_SHORT).show();
                        }
                    }
                }
        );
    }
    public void inicializarComponentes(){
        campoNome   = findViewById(R.id.txtCadNome);
        campoEmail  = findViewById(R.id.txtCadEmail);
        campoSenha  = findViewById(R.id.txtCadSenha);
        btCadastrar = findViewById(R.id.btnCadastrar);
        progressBar = findViewById(R.id.progressCadastro);
        campoNome.requestFocus();

    }

}
