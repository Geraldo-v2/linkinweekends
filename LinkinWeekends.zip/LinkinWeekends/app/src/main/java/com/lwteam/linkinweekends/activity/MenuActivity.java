package com.lwteam.linkinweekends.activity;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;

import android.view.Menu;
import android.view.MenuItem;

import com.ittianyu.bottomnavigationviewex.BottomNavigationViewEx;
import com.lwteam.linkinweekends.R;
import com.lwteam.linkinweekends.fragment.DestaquesFragment;
import com.lwteam.linkinweekends.fragment.FavoritosFragment;
import com.lwteam.linkinweekends.fragment.HomeFragment;

public class MenuActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        //CONFIGURAR O BOTTON NAVIGATIONVIEW (MENU INFERIOR DE 3 BOTOES
        FragmentManager fragmentManager = getSupportFragmentManager();
        final FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.viewPager, new HomeFragment()).commit();

        //CONFIGURACOES INICIAS
        BottomNavigationViewEx bottomNavigationViewEx = findViewById(R.id.bottomNavigation);
        bottomNavigationViewEx.enableAnimation(true);
        bottomNavigationViewEx.enableItemShiftingMode(true);
        bottomNavigationViewEx.enableShiftingMode(false);
        bottomNavigationViewEx.setTextVisibility(true);

        //HABILITAR NAVEGACAO DO MENU INFERIOR
        habilitarNavegacao(bottomNavigationViewEx);

        //CONFIGURA QUAL FRAGMENT VAI SER INICALIZADO, INDICE COMECA EM 0
        final Menu menu = bottomNavigationViewEx.getMenu();
        final MenuItem menuItem = menu.getItem(1);
        menuItem.setChecked(true);
    }

    //CONFIGURA AS FUNCOES DOS BOTOES DO NAVIGATION

    private void habilitarNavegacao(BottomNavigationViewEx viewEx) {
        viewEx.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                FragmentManager fragmentManager = getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                switch (menuItem.getItemId()) {
                    case R.id.ic_home:
                        fragmentTransaction.replace(R.id.viewPager, new HomeFragment()).commit();
                        return true;
                    case R.id.ic_fav:
                        fragmentTransaction.replace(R.id.viewPager, new FavoritosFragment()).commit();
                        return true;
                    case R.id.ic_destaques:
                        fragmentTransaction.replace(R.id.viewPager, new DestaquesFragment()).commit();
                        return true;
                }
                return false;
            }
        });
    }
}
