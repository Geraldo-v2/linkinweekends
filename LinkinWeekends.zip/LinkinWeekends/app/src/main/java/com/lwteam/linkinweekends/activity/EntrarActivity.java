package com.lwteam.linkinweekends.activity;

import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.lwteam.linkinweekends.R;
import com.lwteam.linkinweekends.helper.ConfiguracaoFirebase;
import com.lwteam.linkinweekends.model.Usuario;

public class EntrarActivity extends AppCompatActivity {
    private EditText campoEmail, campoSenha;
    private Button btEntrar;

    private Usuario usuario;

    private FirebaseAuth autenticacao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_entrar);
        getSupportActionBar().hide();
        verificarUsuarioLogado();
        inicializarComponentes();
        //fazer login usuario
        btEntrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String textoEmail = campoEmail.getText().toString();
                String textoSenha = campoSenha.getText().toString();


                if(!textoEmail.isEmpty()){
                    if(!textoSenha.isEmpty()){
                        usuario=new Usuario();
                        usuario.setEmail(textoEmail);
                        usuario.setSenha(textoSenha);
                        validarLogin(usuario);
                    }else{
                        Toast.makeText(EntrarActivity.this,"Preencha a senha!",Toast.LENGTH_SHORT).show();
                    }
                }else{
                    Toast.makeText(EntrarActivity.this,"Preencha o email!",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    public void verificarUsuarioLogado(){
            autenticacao = ConfiguracaoFirebase.getFirebaseAutenticacao();
            if(autenticacao.getCurrentUser()!=null){
                startActivity(new Intent(getApplicationContext(),MenuActivity.class));
                finish();
            }
    }
    public void validarLogin(Usuario usuario){
       // btEntrar.();

        autenticacao = ConfiguracaoFirebase.getFirebaseAutenticacao();

        autenticacao.signInWithEmailAndPassword(
                usuario.getEmail(),
                usuario.getSenha()
        ).addOnCompleteListener(
                new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()){
                            //btEntrar.doneLoadingAnimation(Color.parseColor("#333639"),BitmapFactory.decodeResource(getResources(),R.drawable.ic_done_white_48dp));
                            startActivity(new Intent(getApplicationContext(),MenuActivity.class));
                            finish();
                        }else {
                            Toast.makeText(EntrarActivity.this,"Erro ao fazer Login",Toast.LENGTH_SHORT).show();
                          // btEntrar.doneLoadingAnimation(Color.parseColor("#333639"),BitmapFactory.decodeResource(getResources(),R.drawable.ic_close_black_24dp));
                        }
                    }
                }
        );
    }
    public void inicializarComponentes(){
        campoEmail = findViewById(R.id.txtLoginEmail);
        campoSenha = findViewById(R.id.txtLoginSenha);
        btEntrar = findViewById(R.id.btnEntrar);
        campoEmail.requestFocus();

    }
}
